var ProofOfProduceQuality = artifacts.require("./ProofOfProduceQuality.sol");

module.exports = function(deployer) {
  deployer.deploy(ProofOfProduceQuality);
};
